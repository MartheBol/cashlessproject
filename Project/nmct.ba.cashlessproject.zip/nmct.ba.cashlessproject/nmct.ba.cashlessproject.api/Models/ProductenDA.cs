﻿using nmct.ba.cashlessproject.api.Helper;
using nmct.ba.cashlessproject.model.Klanten;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Security.Claims;
using System.Web;

namespace nmct.ba.cashlessproject.api.Models
{
    public class ProductenDA
    {

        private const string CONNECTIONSTRING = "ConnectionStringKlanten";

        public static List<Products> GetProducts()
        {
            List<Products> list = new List<Products>();

            string sql = "SELECT ID, ProductName, Price FROM Products";
            DbDataReader reader = Database.GetData(CONNECTIONSTRING, sql);

            while (reader.Read())
            {
                Products product = new Products();
                product.Id = reader["ID"].ToString();
                product.ProductName = reader["ProductName"].ToString();
                product.Price = Convert.ToDouble(reader["Price"]);
                list.Add(product);
            }

            reader.Close();
            return list;

        }

 
        //verwijderen van een product
        public static void DeleteProduct(int id)
        {
            string sql = "DELETE FROM Products WHERE ID = @ID";
            DbParameter par = Database.AddParameter(CONNECTIONSTRING, "@ID", id);
            Database.ModifyData(CONNECTIONSTRING, sql, par);
        }

        public static int AddProduct(Products p)
        {
            string productName = p.ProductName;

                string sql = "INSERT INTO Products VALUES (@ProductName, @Price)";
       
                DbParameter par1 = Database.AddParameter(CONNECTIONSTRING, "@ProductName", productName);
             
                return Database.InsertData(CONNECTIONSTRING, sql, par1);
            
        }

       


  
       

       

    }
}